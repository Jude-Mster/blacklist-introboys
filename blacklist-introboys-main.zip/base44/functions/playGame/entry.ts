import { createClientFromRequest } from 'npm:@base44/sdk@0.8.52';
import {
  getSettings, getMemberByUserId, changePoints, withMemberLock, houseEdge, todayStr,
  resolveCoinFlip, resolveDragonDice, resolveLanternSlots, resolveSkyWheel,
  WHEEL_SEGMENTS, UserError, errorResponse
} from '../../shared/points.ts';

const GAME_LABEL = {
  coinflip: 'Yin Yang Toss',
  dragondice: 'Dragon Dice',
  lanternslots: 'Lantern Slots',
  skywheel: 'Twelve Skies Wheel'
};

export default async function(req) {
  try {
    const b = createClientFromRequest(req);
    const user = await b.auth.me();
    if (!user) throw new UserError('Log in first.', 401);
    let payload; try { payload = await req.json(); } catch { payload = {}; }
    const { game, wager, choice } = payload;

    const found = await getMemberByUserId(b, user.id);
    if (!found) throw new UserError('Link your Discord account first.');

    const settings = await getSettings(b);
    if (!Array.isArray(settings.games_enabled) || !settings.games_enabled.includes(game))
      throw new UserError('This game is closed right now.');
    const edge = houseEdge(settings);

    const w = Math.floor(Number(wager));
    if (!Number.isInteger(w) || w < 1) throw new UserError('Enter a wager.');
    if (w < settings.min_bet) throw new UserError(`The minimum wager is ${settings.min_bet}.`);
    if (w > settings.max_bet) throw new UserError(`The maximum wager is ${settings.max_bet}.`);

    // Validate the pick before taking the lock.
    let resolve;
    if (game === 'coinflip') {
      if (!['heads', 'tails'].includes(choice)) throw new UserError('Pick Yang or Yin.');
      resolve = () => resolveCoinFlip(w, choice, edge);
    } else if (game === 'dragondice') {
      const target = Math.floor(Number(choice && choice.target));
      const direction = choice && choice.direction;
      if (!['over', 'under'].includes(direction)) throw new UserError('Pick over or under.');
      if (!Number.isInteger(target) || target < 2 || target > 98) throw new UserError('The target must be between 2 and 98.');
      resolve = () => resolveDragonDice(w, target, direction, edge);
    } else if (game === 'lanternslots') {
      resolve = () => resolveLanternSlots(w, edge);
    } else if (game === 'skywheel') {
      if (!WHEEL_SEGMENTS.includes(choice)) throw new UserError('Pick a faction.');
      resolve = () => resolveSkyWheel(w, choice, edge);
    } else {
      throw new UserError('Unknown game.');
    }

    const result = await withMemberLock(b, found.id, async () => {
      // Re-read inside the lock so the checks use the latest balance.
      const member = await b.asServiceRole.entities.Member.get(found.id);
      if (member.banned) throw new UserError('You are banned from the games.', 403);
      if (w > (member.points || 0)) throw new UserError('Not enough points for that wager.');

      const today = todayStr();
      const usedToday = member.daily_bet_date === today ? (member.daily_bet_total || 0) : 0;
      if (usedToday + w > settings.daily_bet_cap) {
        const left = Math.max(0, settings.daily_bet_cap - usedToday);
        throw new UserError(left ? `Daily wager limit: ${left} left today.` : 'Daily wager limit reached. It resets at 00:00 UTC.');
      }

      const r = resolve();
      const net = r.payout - w;
      const { balance } = await changePoints(b, member.id, net, 'game', `${GAME_LABEL[game]} ${r.won ? 'win' : 'loss'}`, null);
      await b.asServiceRole.entities.Member.update(member.id, { daily_bet_total: usedToday + w, daily_bet_date: today });
      await b.asServiceRole.entities.Bet.create({
        member_id: member.id,
        discord_id: member.discord_id,
        game,
        wager: w,
        payout: r.payout,
        won: r.won,
        outcome: r.outcome
      });
      return { ...r, balance, wager: w, net, wageredToday: usedToday + w };
    });

    return Response.json(result);
  } catch (e) {
    return errorResponse(e);
  }
}
