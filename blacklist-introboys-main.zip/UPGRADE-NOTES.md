# Guild hall upgrade

## What changed

**Login and linking**
- Fixed the setup deadlock: linking required a server ID in Settings, but only a linked leader could set it. The app owner (your Base44 admin account) now always gets in and becomes Guild Master, so you can fill in Settings.
- The owner of the Discord server is also made Guild Master automatically.
- Discord IDs are always compared as text, so long IDs can't be rounded.
- Failed links go back to a themed page that explains what happened (not in the server, cancelled, expired, and so on) instead of a plain-text error. People not in the server get a "Join our Discord server" button.
- The Discord login always opens at the top level, so it no longer breaks inside the Base44 preview frame.

**Points safety**
- Bets, daily spins and awards now take a short per-member lock, so double-tapping can't spend the same points twice or claim the daily wheel twice.
- Unbiased random numbers for every game.
- Settings are validated (server ID format, wager ranges, 2 to 12 wheel prizes).

**Games**
- Yin Yang Toss: 3D cash-coin flip.
- Dragon Dice: win zone on a 1 to 100 track, an animated pearl and count-up roll, and an over/under swap.
- Lantern Slots: real spinning reels that stop left to right, drawn symbols instead of emoji, and a payout table that follows the house edge (three seals pays 50×).
- New: Twelve Skies Wheel. Back Guanyin, Fujin, Jinong or the Dragon on a 12-segment wheel.
- All games show the potential win before you play, a history strip of your last results, and the daily wager left.
- The daily reward is now a real spinning wheel on the dashboard with a countdown to the next spin.

**Look**
- TwelveSky night theme: MMO-style game windows with bronze frames and gilt corners, Shippori Mincho headings, an ink-wash scene of floating peaks, and a skill-bar style bottom navigation on phones.
- Roles show as Guild Master, Elder and Disciple. The leader can promote Elders from the admin hall.
- New rankings podium, character card with rank and game stats, and Discord avatars that fall back to an initial if they fail to load.

## Deploying

1. Replace the files in your repo with these and push. Base44 syncs from git.
2. Publish from the Base44 dashboard.
3. Optional secrets:
   - `DISCORD_GUILD_ID`: used if the Settings server ID is blank.
   - `APP_URL`: your site's address, if Discord callbacks ever return to the wrong domain.
4. Log in with your owner account, link Discord, then open Admin → Guild settings, paste your server ID and invite link, and save.
5. Turn on "Twelve Skies Wheel" under Open games if it isn't already.
